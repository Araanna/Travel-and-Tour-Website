<?php
    $con = mysqli_connet("localhost","root","","signin") or die(myslq_error());
    
?>